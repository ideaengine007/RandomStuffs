<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_bank_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
} 


$name=$_POST['name'];
$age=$_POST['age'];
$group=$_POST['blood_group'];
$contact=$_POST['contact_no'];
$dob=$_POST['date_of_birth'];
$mail=$_POST['email'];


$sql = "INSERT INTO donor (name, age ,blood_group, contact_no, date_of_birth, email)  VALUES ('$name','$age','$group','$contact','$dob','$mail')";

if ($conn->query($sql)==TRUE) {
echo "Successfully submitted.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>