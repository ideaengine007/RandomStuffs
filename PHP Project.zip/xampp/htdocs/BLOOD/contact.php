<?php
$servername = "localhost";
$username = "root";
$password = "";
$conn = new mysqli($servername,$username,$password, "blood_bank_management");
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

$mail = $_POST["email"];
$mess = htmlspecialchars($_POST["message"]);

$sql = "INSERT INTO feedback(mail,mess) VALUES('$mail','$mess')";

if ($conn->query($sql) === TRUE) {
    echo "Your message has been sent.";
} else {
    echo "Some error popped up". $conn->error;
}