<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_bank_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
} 


$q=$_POST['name'];
$w=$_POST['blood_group'];
$e=$_POST['amount'];
$r=$_POST['contact'];

$sql = "INSERT INTO request_for_blood (name, blood_group, amount, contact)  VALUES ('$q','$w','$e','$r')";
if ($conn->query($sql) === TRUE) {
    echo "Your request has been received.";
} else {
    echo "Some error popped up". $conn->error;
}

$conn->close();
?>