<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_bank_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
} 


$blood=$_POST["blood_group"];
$amount=$_POST["amount"];
$sql = "SELECT  `name`, `age`, `contact_no`,`amount` FROM `donor` WHERE blood_group like '$blood' and amount > '$amount'";
if($conn->connect_error){
    echo 'Connection Failed: '.$conn->connect_error;
    }else{
	$res=$conn->query($sql) or die($conn->error);
	if (mysqli_num_rows($res) > 0){
		
        while($row=$res->fetch_assoc()){
            echo "<table border='4' class='stats' cellspacing='0'>
            <tr>
            <td class='head' colspan='8'>Stock Data User-Wise</td>
              </tr>
            <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Contact Number</th>
            <th>Amount(in ml)</th>
            </tr>";
              echo "<tr>";
              echo "<td>" . $row["name"] . "</td>";
              echo "<td>" . $row["age"] . "</td>";
              echo "<td>" . " +91".$row["contact_no"] . "</td>";
              echo "<td>" . $row["amount"] . "</td>";
              echo "</tr>";
    		  echo "</table>";
            }
     } 
     else{
     	echo "Not Found.";
     }
   }      
$conn->close();
?>