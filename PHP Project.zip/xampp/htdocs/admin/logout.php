<?php

require 'php/DBConnect.php';
$db = new DBConnect();
$db->logout();
?>
