<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
} 

$username=$_POST['username'];
$password=$_POST['password'];


$sql = "INSERT INTO db_users (username, password)  VALUES ('$username','$password')";

if ($conn->query($sql)==TRUE) {
echo "Successfully submitted.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>