<?php

/* config/form_display/form_bottom.twig */
class __TwigTemplate_7bf6b90545ed5d62ceb365e002496cfe6c1262dace22f916b47239a8d961b93f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "</form>
";
    }

    public function getTemplateName()
    {
        return "config/form_display/form_bottom.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "config/form_display/form_bottom.twig", "C:\\xampp\\phpMyAdmin\\templates\\config\\form_display\\form_bottom.twig");
    }
}
